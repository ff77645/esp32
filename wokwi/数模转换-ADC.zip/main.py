import time
from machine import Pin, ADC,PWM

# 在 26 引脚创建 ADC 对象
adc = ADC(Pin(26),atten=ADC.ATTN_11DB)

# 获取 ADC 值
# 测量精度为 12 位，返回 0-4095（表示 0-1V）
# val = adc.read()
# 返回 0-65535 范围内的整数。返回值表示 ADC 获取的原始读数，按比例缩放，最小值为 0，最大值为 65535。
# val_u16 = adc.read_u16()

# 配置衰减器，能增加电压测量范围，参数可以是 ADC_ATTN_0DB（0dB 衰减，最大输出电压为 1 V, 默认配置）
# ADC_ATTN_2_5DB（2.5dB 衰减，最大输出电压为 1.34 V）、
# ADC_ATTN_6DB（6dB 衰减，最大输出电压为 2 V）、
# ADC_ATTN_11DB（11dB 衰减，最大输出电压为 3.3 V）
# adc.atten(ADC.ATTN_11DB)


# 创建 LED PWM 控制对象
led = PWM(Pin(13, Pin.OUT), freq=1000)

while True:
    led.duty_u16(adc.read_u16())
    time.sleep(0.1)