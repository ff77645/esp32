from machine import Pin
import time

# ESP32 Pin assignment 
pin_index_list = [12,14,27,26,25]

led_pin_list = []

for i in pin_index_list:
    led_pin_list.append(Pin(i,Pin.OUT))


num = len(led_pin_list)

for led_pin in led_pin_list:
    led_pin.off()

delay = 0.1

while True:
    
    # # 逐个点亮LED
    # for led_pin in led_pin_list:
    #     led_pin.on()
    #     time.sleep(delay)

    # # 逐个熄灭
    # for led_pin in led_pin_list:
    #     led_pin.off()
    #     time.sleep(delay)


    # 逐个点亮
    for i in range(num):
        led_pin_list[i].on()

        if i == 0 :
            led_pin_list[num - 1].off()
        else:
            led_pin_list[i - 1].off()
        
        time.sleep(0.5)