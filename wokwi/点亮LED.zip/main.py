from machine import Pin
import time

# ESP32 Pin assignment 
p_12 = Pin(12,Pin.OUT)

while True:
    p_12.on()
    time.sleep(0.5)
    p_12.off()
    time.sleep(0.5)
