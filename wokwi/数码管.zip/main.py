from machine import Pin
import time
from seg import Seg


# 创建共阳极数码管对象
seg_object = Seg(a=4, b= 5, c=19, d=21, e=22, f=2, g=15, dp=18)

# 显示 0 - 9
for i in range(10):
    seg_object.display_number(i)
    time.sleep(0.5)