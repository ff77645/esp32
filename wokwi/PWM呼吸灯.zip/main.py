import time
from machine import Pin,PWM


# 从1个引脚中创建PWM对象
led = PWM(Pin(12),freq=2000)

# 获取当前频率
# led.freq()

# 设置当前频率
# led.freq(1000)

# 获取当前占空比
# led.duty()

# 设置当前占空比
# led.duty(200)

while True:
  # 渐亮
  for i in range(1,1024):
    led.duty(i)
    time.sleep_ms(1)

  # 渐暗
  for i in range(1023,0,-1):
    led.duty(i)
    time.sleep_ms(1)



