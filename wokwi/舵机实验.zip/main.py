import time
from machine import Pin,PWM
from servo import Servo


# 定义舵机对象
# my_servo = PWM(Pin(13))

# 定义舵机频率
# my_servo.freq(50)

# while True:
# 使用不同方法控制转动到0°, duty 方法的范围是 0-1023
# 因此,参数值为 1023 // 20  * 0.5 取整等于25
  # my_servo.duty(25)

  # time.sleep(2)

  # 使用 duty_u16() 方法转动到90°, duty_u16 方法的范围是 0-65535,
  # 因此,参数值为 65535 // 20 * 1.5 取整等于 4915

  # my_servo.duty_u16(int(65535 // 20 * 1.5))
  # time.sleep(2)



# 使用包*******************************************************

# 定义舵机控制对象
my_servo = Servo(Pin(13), max_us=2400,)

# 程序入口
if __name__ == '__main__':
    while True:
        my_servo.write_angle(0)
        time.sleep(0.5)
        my_servo.write_angle(45)
        time.sleep(0.5)
        my_servo.write_angle(90)
        time.sleep(0.5)
        my_servo.write_angle(135)
        time.sleep(0.5)
        my_servo.write_angle(180)
        time.sleep(0.5)