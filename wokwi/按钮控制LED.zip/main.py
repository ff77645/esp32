import time
from machine import Pin


# 创建按钮输入引脚,如果引脚的一端接Vcc,则设置下拉电阻,如果一端接的是GND,则配置上拉电阻
pin_button = Pin(14,Pin.IN,Pin.PULL_DOWN)

# 定义LED输出引脚
pin_led = Pin(2,Pin.OUT)

# 判断LED的状态是否改变过
status = 0

while True:
  # 按键消抖
  if pin_button.value() == 1:
    # 睡眠10ms, 如果依然为高电平,说明抖动已消失
    time.sleep_ms(10)
    # 并且 LED 的状态没有改变
    if pin_button.value() == 1 and status == 0:
      pin_led.value(not pin_led.value())
      # LED 的状态发生了变化,即使我持续按着按键,LED 的状态也不应该改变
      status = 1
    # 按键松开,记录LED状态的变量也需要响应的改变
    elif pin_button.value() == 0:
      status = 0



